#include <reg51.h>

sbit p11 = P1 ^ 1;
sbit p13 = P1 ^ 3;
sbit p15 = P1 ^ 5;
sbit p17 = P1 ^ 7;
int gateStatus = 0;
void delay1();
void delay2();
void main(void) {
  while (1) {
    delay1();
    if (p11 == 1 && gateStatus == 0) {
      p13 = 1;
      p15 = 0;
      p17 = 1;
      delay2();
      gateStatus = 1;
    } else if (p11 == 0 && gateStatus == 1) {
      p13 = 1;
      p15 = 1;
      p17 = 0;
      delay2();
      gateStatus = 0;
      p13 = 0;
    } else if (p11 == 1 && gateStatus == 1) {
      p13 = 0;
      p15 = 0;
      p17 = 0;
    }

  }
}

void delay1(){
	int i,j;
     i=0;
    while(i<10){
        j=0;
        while(j<10000){
            j++;
        }
        i++;
    }
}
void delay2(){
	int i,j;
     i=0;
    while(i<10){
        j=0;
        while(j<30000){
            j++;
        }
        i++;
    }
}